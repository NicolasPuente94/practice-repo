function log_out(element) {
    element.innerText=
"Logout";
}

function like_function() {
    alert("ninja was liked");
}

function hide(element) {
    element.remove();
}