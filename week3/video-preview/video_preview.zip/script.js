console.log("page loaded...");

function ply_video(element) {
    element.play("ply_video")
}

function stp_video(element) {
    element.pause("ply_video")
}

function subscribed(element) {
    element.innerText=
"Subscribed";
}

function loged(element) {
    element.innerText=
"Loged";
}